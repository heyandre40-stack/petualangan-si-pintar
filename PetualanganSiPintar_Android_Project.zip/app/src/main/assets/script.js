let selectedClass=1,subject="Matematika",score=0,coins=0,lives=3,level=1,qIndex=0,currentAnswer=0,questions=[];

const $=id=>document.getElementById(id);
function hideAll(){document.querySelectorAll(".screen").forEach(x=>x.classList.add("hidden"))}
function showClass(){hideAll();$("classScreen").classList.remove("hidden")}
function backMenu(){hideAll();$("menu").classList.remove("hidden")}
function showGuide(){hideAll();$("guideScreen").classList.remove("hidden")}
function chooseClass(k){selectedClass=k;$("selectedClass").textContent=k;hideAll();$("subjectScreen").classList.remove("hidden")}
function startGame(s){subject=s;score=0;coins=0;lives=3;level=1;qIndex=0;questions=makeQuestions();hideAll();$("gameScreen").classList.remove("hidden");$("subjectName").textContent=s.toUpperCase();renderQuestion()}
function makeQuestions(){let arr=[];for(let i=0;i<10;i++){let a,b,ans,text;
 if(selectedClass<=2){a=rand(1,10);b=rand(1,10);if(Math.random()<.5){ans=a+b;text=`${a} + ${b} = ?`}else{a=Math.max(a,b);b=Math.min(a,b);ans=a-b;text=`${a} − ${b} = ?`}}
 else if(selectedClass<=4){a=rand(2,10);b=rand(2,10);ans=a*b;text=`${a} × ${b} = ?`}
 else{a=rand(10,50);b=rand(2,10);ans=a+b;text=`${a} + ${b} = ?`}
 arr.push({text,ans})}return arr}
function rand(a,b){return Math.floor(Math.random()*(b-a+1))+a}
function renderQuestion(){let q=questions[qIndex];currentAnswer=q.ans;$("question").textContent=q.text;$("progressText").textContent=`${qIndex+1}/10`;$("progressBar").style.width=`${(qIndex+1)*10}%`;$("feedback").textContent="";$("nextBtn").classList.add("hidden");let vals=new Set([q.ans]);while(vals.size<4){let v=q.ans+rand(-3,3);if(v>=0)vals.add(v)}let choices=[...vals].sort(()=>Math.random()-.5);$("answers").innerHTML=choices.map(v=>`<button class="answer" onclick="answer(this,${v})">${v}</button>`).join("");updateHud()}
function answer(btn,v){if(document.querySelector(".answer.correct,.answer.wrong"))return;if(v===currentAnswer){btn.classList.add("correct");score+=10;coins+=5;level=1+Math.floor(score/50);$("feedback").textContent="🎉 Benar! +10 skor +5 koin";$("character").classList.add("celebrate");setTimeout(()=>$("character").classList.remove("celebrate"),700)}else{btn.classList.add("wrong");lives--;document.querySelectorAll(".answer").forEach(x=>{if(Number(x.textContent)===currentAnswer)x.classList.add("correct")});$("feedback").textContent=`❌ Belum tepat. Jawaban: ${currentAnswer}`;if(lives<=0){setTimeout(gameOver,800);return}}$("nextBtn").classList.remove("hidden");updateHud()}
function nextQuestion(){qIndex++;if(qIndex>=10)gameOver();else renderQuestion()}
function updateHud(){$("score").textContent=score;$("coins").textContent=coins;$("lives").textContent=lives;$("level").textContent=level}
function gameOver(){hideAll();$("gameOver").classList.remove("hidden");$("finalScore").textContent=score;$("finalCoins").textContent=coins}
function restartGame(){startGame(subject)}
