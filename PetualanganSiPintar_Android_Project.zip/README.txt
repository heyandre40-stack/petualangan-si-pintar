PETUALANGAN SI PINTAR - ANDROID

Project ini membungkus game HTML/CSS/JS menjadi aplikasi Android WebView.

CARA MEMBUAT APK GRATIS:
1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini.
3. Masuk tab Actions.
4. Jalankan workflow "Build Android APK" (Run workflow).
5. Setelah selesai, buka hasil workflow -> Artifacts -> Petualangan-Si-Pintar-APK.
6. Download ZIP artifact dan ambil app-debug.apk.

Catatan:
- APK yang dibuat adalah debug APK untuk instalasi/testing.
- Untuk Play Store, perlu signing/release build dan konfigurasi Play App Signing.
